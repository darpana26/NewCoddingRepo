const express = require('express');
const authController = require('../controllers/authController');
const userController = require('../controllers/userController');
const router = express.Router();

router.post('/signUp', authController.signUp, authController.restrictTo('admin'));

router.post('/login', authController.login);

router.post('/logout', authController.logout);

router.post(
  '/',
  authController.protect,
  authController.restrictTo('admin'),
  userController.createUser
);

router.get(
  '/',
  authController.protect,
  authController.restrictTo('admin'),
  userController.getAllUsers
);

router.get(
  '/:id',
  authController.protect,
  userController.getUser
);

module.exports = router;
