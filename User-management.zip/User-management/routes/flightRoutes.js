const express = require('express');
const authController = require('../controllers/authController');
const flightController = require('../controllers/flightController');
const router = express.Router();


router.post(
  '/addFlight',
  authController.protect,
  flightController.addFlight
);

router.get(
  '/',
  authController.protect,
  authController.restrictTo('admin'),
  flightController.getBookFlightList
);

router.get(
  '/:id',
  authController.protect,
  flightController.getBookFlight
);

module.exports = router;
