const User = require('../model/userModel');
const catchAsync = require('../utlis/catchAsync');
const AppError = require('../utlis/appError');

exports.createUser = catchAsync(async (req, res, next) => {
  const checkData = await User.findOne({ email: req.body.email});
  if (checkData) {
    return next(new AppError(`Email ${req.body.email} already in use`, 409));
  }
  
  const user = await User.create(req.body);

  if (!user) {
    return next(
      new AppError('Unable to create User! Please try again later', 404)
    );
  }

  res.status(200).json({
    status: 'success',
    result: user,
  });
});

exports.getAllUsers = catchAsync(async (req, res, next) => {
  const user = await User.find();

  if (!user) {
    return next(
      new AppError('Unable to found User! Please try again later!', 404)
    );
  }

  res.status(200).json({
    status: 'success',
    results: user,
  });
});

exports.getUser = catchAsync(async (req, res, next) => {
  const user = await User.findById(req.params.id);

  if (!user) {
    return next(
      new AppError('Unable to found User! Please try again later!', 404)
    );
  }

  res.status(200).json({
    status: 'success',
    results: user,
  });
});