const Flight = require('../model/fligthModel');
const catchAsync = require('../utlis/catchAsync');
const AppError = require('../utlis/appError');

exports.addFlight = catchAsync(async (req, res, next) => {
    const flight = await Flight.create(req.body);

    if (!flight) {
        return next(
            new AppError('Unable to book flight! Please try again later', 404)
        );
    }

    res.status(200).json({
        status: 'success',
        result: flight,
    });
});

exports.getBookFlightList = catchAsync(async (req, res, next) => {
    const flight = await Flight.find();

    if (!flight) {
        return next(
            new AppError('Unable to found flight list! Please try again later!', 404)
        );
    }

    res.status(200).json({
        status: 'success',
        results: flight,
    });
}); 

