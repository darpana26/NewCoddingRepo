const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });
const mongoose = require('mongoose');
const app = require('./app');

const DB = process.env.mongodb;

mongoose.connect(DB, {}).then(() => console.log('Database is connected'));
const port = process.env.PORT || 8000;

const server = app.listen(port, () => {
  console.log(`App is running on port no ${port}`);
});
