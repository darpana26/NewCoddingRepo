const mongoose = require('mongoose');

const FlightSchema = new mongoose.Schema(
  {
    flight_from: {
      type: String,
      required: true
    },
    flight_to: {
        type: String,
        required: true
      },
    price: {
      type: Number,
      required: true
    },
    flight_date: {
      type: Date,
      required: true
    },
    flight_class: {
      type: String,
      required: true
    },
  },
  { timestamps: true }
);

const Flight = mongoose.model('Flight', FlightSchema);

module.exports = Flight;
