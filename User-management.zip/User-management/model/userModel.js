const crypto = require('crypto');
const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, maxlength: 30 },    
    mobile_number: { type: String, required: true, maxlength: 10 },
    address: { type: String, required: true, maxlength: 30 },
    role: {
      type: String,
      required: [true, 'Please provide a role'],
      enum: ['admin', 'user'],
    },
    email: {
      type: String,
      required: [true, 'Please provide your email'],
      minlength: 8,
      unique: true,
      lowercase: true,
      validate: [validator.isEmail, 'Please Provide a Valid Email'],
    },
    password: {
      type: String,
      required: [true, 'Please provide a password'],
      minlength: 8,
      select: false,
    },
    confirm_password: {
      type: String,
      validate: {
        validator: function(el) {
          return el === this.password;
        },
        message: 'Passwords are not the same',
      },
    },
  },
  { timestamps: true }
);

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();

  this.password = await bcrypt.hash(this.password, 12);

  this.confirm_password = undefined;
  return next();
});

userSchema.methods.correctPassword = async function (
  candidatePassword,
  userPassword
) {
  return await bcrypt.compare(candidatePassword, userPassword);
};

userSchema.methods.createPasswordResetToken = function () {
  const resetToken = crypto.randomBytes(32).toString('hex');
  this.passwordResetToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');
  this.passwordResetTokenExpires = Date.now() + 2880 * 60 * 1000;
  return resetToken;
};

userSchema.statics.newLogin = function login(id, callback) {
  return this.findByIdAndUpdate(
    id,
    { $set: { lastLogin: Date.now() } },
    { new: true },
    callback
  );
};

userSchema.methods.createAccountActivationToken = function () {
  const resetToken = crypto.randomBytes(32).toString('hex');
  this.activationToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');
  this.activationTokenExpires = Date.now() + 2880 * 60 * 1000;
  return resetToken;
};

const User = mongoose.model('User', userSchema);

module.exports = User;
